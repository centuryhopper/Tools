from .edit_distance import *

__doc__ = edit_distance.__doc__
if hasattr(edit_distance, "__all__"):
    __all__ = edit_distance.__all__