#include "../include/data_structures/BST.hpp"

#include <chrono>          // std::chrono, std::chrono_literals
#include <filesystem>      // std::filesystem
#include <memory_resource> // std::pmr
#include <ranges>          // std::ranges, std::ranges::views
#include <string>          // std::string_literals ("abc"s)

namespace fs = std::filesystem;
namespace rng = std::ranges;
namespace rv = std::views;
namespace chr = std::chrono;
namespace pmr = std::pmr;

using namespace std::literals;

namespace data_structures {
template <typename T>
  requires std::totally_ordered<T>
Node<T> *BST<T>::findMin(Node<T> *node) const {
  if (!node)
    return nullptr;
  while (node->left) {
    node = node->left;
  }

  return node;
}

template <typename T>
  requires std::totally_ordered<T>
Node<T> *BST<T>::findMax(Node<T> *node) const {
  if (!node)
    return nullptr;
  while (node->right) {
    node = node->right;
  }

  return node;
}

template <typename T>
  requires std::totally_ordered<T>
int BST<T>::height() const {
  return height(this->root);
}

/*
50
/    \
30      70
/  \    /  \
20   40  60   80
/          \     \
10           65     90
*/
template <typename T>
  requires std::totally_ordered<T>
int BST<T>::height(Node<T> *node) const {
  int lvl = -1;
  if (!node)
    return lvl;
  std::queue<Node<T> *> q;
  q.push(node);
  q.push(nullptr);
  while (!q.empty()) {
    auto poppedNode = q.front();
    q.pop();
    if (!poppedNode) {
      lvl += 1;
      // only need to push a null node if q still has nodes left
      if (!q.empty())
        q.push(nullptr);
      continue;
    }
    if (poppedNode->left)
      q.push(poppedNode->left);
    if (poppedNode->right)
      q.push(poppedNode->right);
  }

  return lvl;
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::remove(T value) {
  this->root = this->remove(this->root, value);
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::insert(T value) {
  this->root = this->insert(this->root, value);
}

template <typename T>
  requires std::totally_ordered<T>
std::optional<T> BST<T>::max() const {
  auto node = this->findMax(this->root);
  if (!node) {
    return std::nullopt;
  }
  return node->value;
}

template <typename T>
  requires std::totally_ordered<T>
std::optional<T> BST<T>::min() const {
  auto node = this->findMin(this->root);
  if (!node) {
    return std::nullopt;
  }
  return node->value;
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::printInOrder() const {
  this->inorder(this->root);
  printf("\n");
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::printPreOrder() const {
  this->preorder(this->root);
  printf("\n");
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::printPostOrder() const {
  this->postorder(this->root);
  printf("\n");
}

template <typename T>
  requires std::totally_ordered<T>
bool BST<T>::empty() const {
  return this->root == nullptr;
}

template <typename T>
  requires std::totally_ordered<T>
BST<T>::BST() {
  root = nullptr;
}

template <typename T>
  requires std::totally_ordered<T>
BST<T>::~BST() {
  destroy(this->root);
  this->root = nullptr;
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::destroy(Node<T> *node) {
  if (node == nullptr) {
    return;
  }

  destroy(node->left);
  destroy(node->right);
  node->left = nullptr;
  node->right = nullptr;
  delete node;
}

template <typename T>
  requires std::totally_ordered<T>
BST<T>::BST(T value) {
  this->root = new Node<T>(value);
}

template <typename T>
  requires std::totally_ordered<T>
Node<T> *BST<T>::insert(Node<T> *node, T value) {
  if (node == nullptr)
    return new Node<T>(value);

  if (value < node->value)
    node->left = insert(node->left, value);
  else if (value > node->value)
    node->right = insert(node->right, value);
  // else: duplicate, do nothing

  return node;
}

/*
    CASE 3: Node has TWO children

    Example:

        10
        /  \
    5    15
            /
        12

    Delete(10)

    Step 1:
    Find inorder successor
    -> smallest value in right subtree

    Right subtree:

        15
        /
    12

    Successor = 12

    Step 2:
    Copy successor value into current node

        12
        /  \
        5    15
            /
        12

    Step 3:
    Delete the duplicate successor node from right subtree

        12
        /  \
        5    15

    Tree remains a valid BST.

    ------------------------------------------------
*/
template <typename T>
  requires std::totally_ordered<T>
Node<T> *BST<T>::remove(Node<T> *node, T value) {
  if (!node)
    return nullptr;
  if (value < node->value) {
    node->left = remove(node->left, value);
    return node;
  } else if (value > node->value) {
    node->right = remove(node->right, value);
    return node;
  }

  // handle 3 cases
  if (!node->left && !node->right) {
    delete node;
    return nullptr;
  }

  // std::cout << "node to delete: " << node->value << std::endl;

  // std::cout << "node left is null: " << (node->left == nullptr) << std::endl;
  // std::cout << "node right is null: " << (node->right == nullptr) <<
  // std::endl;

  if (height(node->left) > height(node->right)) {
    // go for inorder predecessor
    Node<T> *predecessor = findMax(node->left);
    node->value = predecessor->value;
    node->left = remove(node->left, predecessor->value);
    return node;
  } else {
    // go for inorder predecessor
    // printf("hi\n");

    Node<T> *successor = findMin(node->right);
    // printf("hi\n");

    // printf("successor: %d\n", successor == nullptr);
    // printf("node->value: %d\n", node->value);

    node->value = successor->value;
    node->right = remove(node->right, successor->value);
    return node;
  }
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::preorder(Node<T> *node) const {
  if (node == nullptr) {
    return;
  }

  // fmt::print("{} ",node->value);

  std::cout << node->value << " " << std::endl;
  preorder(node->left);
  preorder(node->right);
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::postorder(Node<T> *node) const {
  if (node == nullptr) {
    return;
  }

  postorder(node->left);
  postorder(node->right);
  // fmt::print("{} ",node->value);
  std::cout << node->value << " ";
}

template <typename T>
  requires std::totally_ordered<T>
void BST<T>::inorder(Node<T> *node) const {
  if (node == nullptr) {
    return;
  }

  inorder(node->left);
  // fmt::print("{} ",node->value);
  std::cout << node->value << " "; //<< std::endl;
  inorder(node->right);
}

template <typename T>
  requires std::totally_ordered<T>
bool BST<T>::contains(T value) const {
  return this->contains(this->root, value);
}

template <typename T>
  requires std::totally_ordered<T>
bool BST<T>::contains(Node<T> *node, T value) const {
  if (node == nullptr)
    return false;

  if (node->value == value) {
    return true;
  }

  return contains(node->left, value) || contains(node->right, value);
}

} // namespace data_structures

template class data_structures::BST<int>;